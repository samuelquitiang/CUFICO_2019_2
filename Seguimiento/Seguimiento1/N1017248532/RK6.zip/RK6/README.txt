Solo debe correr el .py, dicho archivo compilará el código en C++ y luego graficará los datos que dicho código imprime en pantalla (o en esta caso, en 4 archivos .csv) 
