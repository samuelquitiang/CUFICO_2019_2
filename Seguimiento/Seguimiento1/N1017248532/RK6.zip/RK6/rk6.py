import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os #Usare OS para compilar el codigo en C++

NP = np.array([10,100,1000,10000])
os.system("g++ -o rk6 rk6.cpp")

for index,i in enumerate(NP):
    os.system("./rk6 {} > rk6{}.csv".format(i,index)) #Corre el codigo compilado con cada numero de puntos como flag y crea un .csv

d0 = pd.read_csv("rk60.csv")
d1 = pd.read_csv("rk61.csv")
d2 = pd.read_csv("rk62.csv")
d3 = pd.read_csv("rk63.csv")

fig = plt.figure()
ax1 = fig.add_subplot(131)
ax2 = fig.add_subplot(132)
ax3 = fig.add_subplot(133)

ax1.set_title("Funciones")
ax2.set_title("Func vs Sol exacta")
ax3.set_title("h (paso) vs Divergencia")

ExactSolution = lambda x: x - 1 + 2*np.exp(-x)

for i,j in zip([d0,d1,d2,d3],NP):
    ax1.plot(i["X"],i["Y"], label ="{} puntos".format(j))


for i,j in zip([d0,d1,d2,d3],NP):
    ax2.semilogy(i["X"], np.abs(i["Y"] - ExactSolution(i["X"])), label = "{} puntos".format(j))


diff = []
steps = []

for i in [d0,d1,d2,d3]:
    steps.append((i["X"].iloc[-1] - i["X"].iloc[0])/len(i["X"]))
    diff.append(np.mean(np.abs(i["Y"] - ExactSolution(i["X"]))))
    

ax3.plot(steps,diff, label = "rk6")


ax1.legend(loc = "upper left")
ax2.legend(loc = "lower left")
ax3.legend(loc = "upper left")

ax1.grid()
ax2.grid()
ax3.grid()

plt.show()

    
