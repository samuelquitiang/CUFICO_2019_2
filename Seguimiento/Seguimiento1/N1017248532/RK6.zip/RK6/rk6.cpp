#include <iostream>

using namespace std;

typedef float (* vFunctionCall)(float arg1, float arg2); //Esto lo uso para poder llamar una funcion dentro de otra funcion

float RK6(float xn, float yn, float h ,vFunctionCall F)
{
  float k1, k2, k3, k4, k5, k6;

  //Definiendo parametros
  float a21 = 1.0/3.0;
  float a31 = 123.0/256.0, a32 = 315.0/256.0;
  float a41 = 193.0/750.0, a42 = 189.0/1250.0, a43 = 176.0/1875.0;
  float a51 = 26/81.0, a52 = 7/15.0, a53 = 304.0/4455.0, a54 = 176.0/297.0;
  float a61 = 151.0/150.0, a62 = 351.0/250.0, a63 = 304.0/4125.0, a64 = 5.0/77.0, a65 = 243.0/175.0;

  float c2 = 1.0/3.0, c3 = 3.0/4.0, c4 = 1.0/5.0, c5 = 2.0/3.0, c6 = 1.0;
  float b1 = 1.0/24.0, b2 = 0.0, b3 = 0.0, b4 = 125.0/336.0, b5 = 27.0/56.0, b6 = 5.0/48.0;

  k1 = F(yn,xn);
  k2 = F(yn + h*a21*k1, xn + h*c2);
  k3 = F(yn + h*(a31*k1 + a32*k2), xn + h*c3);
  k4 = F(yn + h*(a41*k1 + a42*k2 + a43*k3), xn + h*c4);
  k5 = F(yn + h*(a51*k1 + a52*k2 + a53*k3 + a54*k4), xn + h*c5);
  k6 = F(yn + h*(a61*k1 + a62*k2 + a63*k3 + a64*k4 + a65*k5), xn + h*c6);

  return yn + h*(b1*k1 + b2*k2 + b3*k3 + b4*k4 + b5*k5 + b6*k6);
}


float EqDef(float y,float x)
{
  return x-y;
}

int main(int argc, char** argv) //Esto lo hago para usar un flag que me permita determinar el numero de puntos que se van a usar
{
  
  float x0 = 0.0, xf = 5.0;
  float y = 1.0;
  
  int steps = atoi(argv[1]); //Usando el flag para definir el numero de pasos

  float dx = (xf-x0)/steps;

  //Imprimo los datos de esta forma con el objetivo de poder manipularlos facilmente con pandas
  cout << "X,Y" << endl;
  cout << x0 << "," << y << endl;
  
  for(float i = x0+dx; i <= xf; i += dx)
    {
      
      y = RK6(i, y, dx, (vFunctionCall)EqDef);
      cout << i << "," << y << endl;	
    }
  
  return 0;
}
